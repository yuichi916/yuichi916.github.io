# -*- coding: utf-8 -*-
"""台本から声を作り、行ごとの時刻（build/timing.json）を決める。

  python voice.py script.json              VOICEVOX（http://127.0.0.1:50021）で1行ずつ声を作る
  python voice.py script.json --no-voice   声なし。字幕の字数から長さを見積もる（VOICEVOX が無くても試せる）

  声を作る前に、VOICEVOX が実際に読むカタカナを取り出して、よくある読み違いと照らし合わせる。
  見つかったら、声を作らずに止まる（終了コード 1）。登録していない読み違いもあるので、
  印字される全行のカナは目でも見る。
  出力: build/timing.json・build/voice.wav（声ありのとき）・build/voice/01.wav …
"""
import argparse, json, sys, urllib.error, urllib.parse, urllib.request, wave
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    if hasattr(_s, "reconfigure"):
        _s.reconfigure(encoding="utf-8", errors="replace")   # Windows のターミナルでも日本語を崩さない

BUILD = Path(__file__).resolve().parent / "build"
LEAD, GAP, TAIL = 0.4, 0.35, 1.0      # 最初の間・行と行の間・最後の余白（秒）

# よくある読み違い: (出てはいけない読み, 正しい読み（かな）, この字が台本の text にあるときだけ見る)
# 「一人前（いちにんまえ）」「七人の侍（しちにん）」のように前後で読みが変わる語は、ここに入れない。
NG = [("ゴジン", "ごにん", "五人"), ("シニン", "よにん", "四人"), ("シホン", "よんほん", "四本")]


def post(url, path, params, body=None):
    data = json.dumps(body).encode("utf-8") if body is not None else b""
    req = urllib.request.Request(f"{url}{path}?{urllib.parse.urlencode(params)}", data=data, method="POST",
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.read()


def kana_of(url, text, spk):
    q = json.loads(post(url, "/audio_query", {"text": text, "speaker": spk}))
    return q, "".join(m["text"] for ph in q["accent_phrases"] for m in ph["moras"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("script")
    ap.add_argument("--no-voice", action="store_true")
    ap.add_argument("--url", default="http://127.0.0.1:50021")
    a = ap.parse_args()
    sc = json.loads(Path(a.script).read_text(encoding="utf-8-sig"))   # BOM 付き（PowerShell で保存したもの）も読む
    lines = sc.get("lines") or []
    miss = [i for i, ln in enumerate(lines, 1) if "caption" not in ln or (not a.no_voice and not str(ln.get("text", "")).strip())]
    if not lines or miss:
        print("NG  台本に lines が無いか、text / caption の無い行がある:", miss or "lines が空")
        return 1
    BUILD.mkdir(exist_ok=True)
    clips = []

    if a.no_voice:
        durs = [max(1.8, len(ln["caption"]) / 6.5 + 0.5) for ln in lines]
    else:
        try:
            urllib.request.urlopen(a.url + "/version", timeout=5).read()
        except Exception:
            print(f"NG  VOICEVOX に届かない（{a.url}）。VOICEVOX を起動するか、--no-voice で試す")
            return 1
        spk, queries, bad = sc.get("speaker", 3), [], []
        try:
            for i, ln in enumerate(lines, 1):
                q, kana = kana_of(a.url, ln["text"], spk)
                q["speedScale"] = sc.get("speed", 1.0)
                print(f"{i:02d}  {kana}")
                if not kana:
                    bad.append(f"{i:02d}行目「{ln['text']}」に読むものが無い（記号や絵文字だけ？）")
                for ng, ok, key in NG:
                    # その字を正しい読みに置き換えて読ませ直し、出てはいけない読みが減るときだけ読み違いとする
                    # （「資本を四本に」の「シホン」は資本の読みなので、置き換えても減らない）
                    if key in ln["text"] and ng in kana:
                        _, fixed = kana_of(a.url, ln["text"].replace(key, ok), spk)
                        if kana.count(ng) > fixed.count(ng):
                            bad.append(f"{i:02d}行目「{ln['text']}」の「{key}」を {ng}… と読む（正しくは {ok}）")
                queries.append(q)
        except urllib.error.HTTPError as e:
            print(f"NG  VOICEVOX がエラーを返した（HTTP {e.code}）。speaker の番号が正しいか、{a.url}/speakers で確かめる")
            return 1
        if bad:
            for b in bad:
                print("NG ", b)
            print("→ 読み上げ用の text を、かなで書き直す（字幕の caption はそのままでよい）")
            return 1
        (BUILD / "voice").mkdir(exist_ok=True)
        durs = []
        for i, q in enumerate(queries, 1):
            p = BUILD / "voice" / f"{i:02d}.wav"
            p.write_bytes(post(a.url, "/synthesis", {"speaker": spk}, q))
            with wave.open(str(p)) as w:
                clips.append((w.getparams(), w.readframes(w.getnframes())))
                durs.append(w.getnframes() / w.getframerate())

    # 声の長さから、字幕を出す時刻と場面を切り替える時刻を決める
    t, out = LEAD, []
    for ln, d in zip(lines, durs):
        out.append({"caption": ln["caption"], "big": ln.get("big", ""), "start": round(t, 3), "dur": round(d, 3)})
        t += d + GAP
    total = round(t - GAP + TAIL, 3)
    tm = {"title": sc.get("title", ""), "total": total, "lines": out}
    (BUILD / "timing.json").write_text(json.dumps(tm, ensure_ascii=False, indent=1), encoding="utf-8")

    voice = BUILD / "voice.wav"
    if clips:                                   # 各行の声を、決めた時刻に並べて1本にする
        prm = clips[0][0]
        step = prm.sampwidth * prm.nchannels
        buf = bytearray()
        for (_, frames), ln in zip(clips, out):
            buf += b"\0" * max(0, int(ln["start"] * prm.framerate) * step - len(buf))
            buf += frames
        buf += b"\0" * max(0, int(total * prm.framerate) * step - len(buf))
        with wave.open(str(voice), "wb") as w:
            w.setnchannels(prm.nchannels); w.setsampwidth(prm.sampwidth); w.setframerate(prm.framerate)
            w.writeframes(bytes(buf))
    elif voice.exists():
        voice.unlink()                          # 前に作った声が残っていると、声なしの試しに混ざる
    print(f"→ {len(out)}行 / {total:.1f}秒  build/timing.json" + ("・build/voice.wav" if clips else "（声なし）"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
