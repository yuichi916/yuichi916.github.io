# -*- coding: utf-8 -*-
"""scene.html を1コマずつ撮って、音の無い mp4 にする。

  python render.py                 （build/timing.json を使う。1秒に30コマ。先に voice.py を流す）
  python render.py --keep-frames   撮ったコマ（build/frames）を消さずに残す
  出力: build/video.mp4（音は mix.py で入れる）
"""
import json, shutil, subprocess, sys, time
from pathlib import Path
from playwright.sync_api import sync_playwright

for _s in (sys.stdout, sys.stderr):
    if hasattr(_s, "reconfigure"):
        _s.reconfigure(encoding="utf-8", errors="replace")

HERE = Path(__file__).resolve().parent
BUILD = HERE / "build"
FPS = 30


def main():
    if not shutil.which("ffmpeg"):
        print("NG  ffmpeg が見つからない（入れたあと、ターミナルを開き直す）")
        return 1
    tj = BUILD / "timing.json"
    if not tj.exists():
        print("NG  build/timing.json が無い。先に voice.py を流す")
        return 1
    tm = json.loads(tj.read_text(encoding="utf-8"))
    out, frames = BUILD / "video.mp4", BUILD / "frames"
    out.unlink(missing_ok=True)            # 失敗したときに、前回の動画が残って紛れないように
    if frames.exists():
        shutil.rmtree(frames)              # 前回のコマが残っていると、新しい動画に古いコマが混ざる
    frames.mkdir(parents=True)
    n = int(round(tm["total"] * FPS))
    t0, errs = time.time(), []
    with sync_playwright() as p:
        br = p.chromium.launch(args=["--force-device-scale-factor=1"])
        pg = br.new_page(viewport={"width": 1080, "height": 1920}, device_scale_factor=1)
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.add_init_script("window.__CAPTURE = true; window.__DATA = " + json.dumps(tm, ensure_ascii=False) + ";")
        pg.goto((HERE / "scene.html").as_uri())
        pg.evaluate("document.fonts.ready.then(() => true)")
        if errs or not pg.evaluate("typeof window.__setTime === 'function'"):
            print("NG  scene.html が動いていない:", (errs or ["window.__setTime が無い"])[0][:160])
            br.close()
            return 1
        for i in range(n):
            pg.evaluate(f"window.__setTime({i / FPS:.4f})")      # i コマ目の時刻を渡してから撮る
            pg.screenshot(path=str(frames / f"{i:05d}.jpg"), type="jpeg", quality=92)
            if i % 150 == 0:
                print(f"  {i}/{n}コマ", flush=True)
        br.close()
    if errs:
        print("NG  ページのエラー:", errs[0][:160])
        return 1
    print(f"{n}コマ撮った（{time.time() - t0:.0f}秒）")
    # コマのフォルダの中で ffmpeg を動かす（フォルダ名に % があっても、連番の指定と混ざらない）
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-framerate", str(FPS), "-i", "%05d.jpg",
                    "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p", str(out)],
                   check=True, cwd=str(frames))
    if "--keep-frames" not in sys.argv:
        shutil.rmtree(frames)              # 1分の動画だと 100MB を超えるので、書き出したら消す
    print("→ build/video.mp4")
    return 0


if __name__ == "__main__":
    sys.exit(main())
