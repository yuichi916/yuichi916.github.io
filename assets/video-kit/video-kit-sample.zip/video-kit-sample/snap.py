# -*- coding: utf-8 -*-
"""指定した時刻の画面を1枚だけ撮る（書き出す前に、目で確かめる用。先に voice.py を流す）。

  python snap.py 7.2          → build/snap_7.2.png
  python snap.py 0.5 7.2 12   → 3枚
"""
import json, sys
from pathlib import Path
from playwright.sync_api import sync_playwright

for _s in (sys.stdout, sys.stderr):
    if hasattr(_s, "reconfigure"):
        _s.reconfigure(encoding="utf-8", errors="replace")

HERE = Path(__file__).resolve().parent
BUILD = HERE / "build"


def main(times):
    tj = BUILD / "timing.json"
    if not tj.exists():
        print("NG  build/timing.json が無い。先に voice.py を流す")
        return 1
    tm = json.loads(tj.read_text(encoding="utf-8"))
    errs = []
    with sync_playwright() as p:
        br = p.chromium.launch()
        pg = br.new_page(viewport={"width": 1080, "height": 1920}, device_scale_factor=1)
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.add_init_script("window.__CAPTURE = true; window.__DATA = " + json.dumps(tm, ensure_ascii=False) + ";")
        pg.goto((HERE / "scene.html").as_uri())
        pg.evaluate("document.fonts.ready.then(() => true)")
        if errs or not pg.evaluate("typeof window.__setTime === 'function'"):
            print("NG  scene.html が動いていない:", (errs or ["window.__setTime が無い"])[0][:160])
            br.close()
            return 1
        for s in times:
            pg.evaluate(f"window.__setTime({float(s)})")
            out = BUILD / f"snap_{s}.png"
            pg.screenshot(path=str(out))
            print(out.relative_to(HERE))
        br.close()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
