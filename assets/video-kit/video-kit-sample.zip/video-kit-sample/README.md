# HTML で作る縦動画のサンプル

編集ソフトを使わずに、台本から縦 1080×1920 のショート動画を作り、公開前の検査まで通すサンプル。
実際に使っている仕組みを、手元の環境に依存しない形に直した（コードは Claude Code に書いてもらったもの）。

## 要るもの

- Python 3.8 以上（3.10 で確認）
- Playwright: `pip install playwright` のあと `python -m playwright install chromium`
- ffmpeg 4.4 以上と ffprobe（ターミナルで `ffmpeg -version` が通ること）
- 声を入れるなら VOICEVOX（起動しておく。`http://127.0.0.1:50021` で待ち受ける）

Mac と Linux では `python` を `python3` に読み替える。Linux は `python -m playwright install --with-deps chromium` でブラウザの部品も入れ、
日本語のフォント（`fonts-noto-cjk` など）も入れる。フォントが無いと字が □ になり、検査では拾えない。
Windows の PowerShell 5.1 で出力をファイルに送るときは、先に `[Console]::OutputEncoding = [Text.Encoding]::UTF8` を打つ。

## まず動かす

```
python make_short.py script.json --no-voice      # 声なし・試し用の和音で、通しだけ試す
python make_short.py script.json                 # VOICEVOX の声を入れる
python make_short.py script.json --bgm 曲.mp3     # BGM を入れる（声の間だけ下がる）
```

できるのは `build/final.mp4`。途中で NG が出たら、その工程で止まる。

## ファイル

| ファイル | すること |
|---|---|
| script.json | 台本。`text` は読み上げ用、`caption` は字幕（`\n` で改行）、`big` は画面の大きな文字。`speaker` は VOICEVOX の話者の番号（3 はずんだもん）、`speed` は話す速さ、`title` は左上の題 |
| scene.html | 画面。`window.__setTime(t)` を呼ぶと t 秒の画面になる。ブラウザで直接開くと、見本の台本（自分の台本ではない）でプレビューが流れる |
| voice.py | 1行ずつ声を作り、その長さから時刻を決める。読み違いと、読むものが無い行は、声を作る前に止める |
| check_layout.py | 書き出す前に、0.2秒ごとに文字の位置を1字ずつ測る |
| render.py | 1コマずつ撮って、音の無い mp4 にする。撮ったコマは書き出したあと消す（残すなら `--keep-frames`） |
| mix.py | 声と BGM を混ぜ（声の間だけ BGM を下げる）、音量を -14 LUFS にそろえる（2パス） |
| video_qc.py | 公開前の検査（音量・音割れ・無音の穴・固まった画面・黒いコマ・冒頭の暗さ） |
| make_short.py | 上の工程を順に流す。書き出す前に長さ（3分まで）を、最後に音声の形（48kHz ステレオが勧め）を見る |
| snap.py | 指定した時刻の画面を1枚撮る（`python snap.py 7.2`）。先に voice.py を流しておく |

## 自分の動画にするとき

- 台本は `script.json` を書き換える。読み違いが出たら、`text` だけをかなで書き直す（字幕の `caption` はそのまま）
- 画面の見た目は `scene.html` を書き換える。動きは必ず `t` から計算する（CSS のアニメーションは使わない）。
  枠にする部品には `data-box`、文字の無い部品で位置を測りたいものには `data-check` を付ける
- 検査の基準は、各スクリプトの先頭の数字（`SAFE_BOTTOM`・`MIN_FONT`・`LUFS_TARGET` など）を変える。
  音量の目標は video_qc.py の `LUFS_TARGET` だけ変えれば、mix.py もそれに合わせる

## ライセンス

MIT（LICENSE を見る）。自由に使い、書き換えてよい。無保証。

## 声のクレジット

VOICEVOX の声を使った動画を公開するときは、「VOICEVOX:ずんだもん」のように使ったキャラクターの表記が要る。
キャラクターごとの利用規約も確かめる。
