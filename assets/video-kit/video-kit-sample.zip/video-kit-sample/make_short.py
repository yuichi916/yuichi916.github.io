# -*- coding: utf-8 -*-
"""台本から縦動画を作り、公開前の検査まで通す。どこかで NG が出たら、その工程で止まる。

  python make_short.py script.json                  声は VOICEVOX（先に起動しておく）
  python make_short.py script.json --bgm 曲.mp3      BGM を入れる（声の間だけ下がる）
  python make_short.py script.json --no-voice       声なし・試し用の和音で、通しだけ試す
  できるもの: build/final.mp4
"""
import argparse, json, subprocess, sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    if hasattr(_s, "reconfigure"):
        _s.reconfigure(encoding="utf-8", errors="replace")

HERE = Path(__file__).resolve().parent
SHORTS_MAX = 180        # 縦か正方形で3分まで Shorts になる（2024年10月15日以降に上げた動画）
MUSIC_NOTE = 60         # これを超えるなら、使う曲の長さの制限に気をつける（曲によっては60秒や30秒まで）


def run(step, args):
    print(f"\n=== {step} ===", flush=True)
    rc = subprocess.run([sys.executable, str(HERE / args[0]), *args[1:]]).returncode
    if rc != 0:
        print(f"\n止めた: 「{step}」で NG（終了コード {rc}）。直してから、もう一度流す")
        sys.exit(rc)


def length_ok(sec):
    if sec > SHORTS_MAX:
        print(f"NG  長さ {sec:.1f}秒。Shorts は{SHORTS_MAX // 60}分まで")
        return False
    print(f"OK  長さ {sec:.1f}秒（{SHORTS_MAX // 60}分以下）")
    if sec > MUSIC_NOTE:
        print(f"注意  {MUSIC_NOTE}秒を超えている。曲を使うなら、その曲を使える長さを確かめる")
    return True


def audio_note(path):
    """YouTube が勧める音声の形（48kHz のステレオ）か。勧めなので、違っても止めない"""
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=sample_rate,channels",
                        "-of", "json", str(path)], capture_output=True, text=True)
    s = (json.loads(r.stdout or "{}").get("streams") or [{}])[0]
    ok = s.get("sample_rate") == "48000" and s.get("channels") == 2
    print(f"{'OK' if ok else '注意'}  音声 {s.get('sample_rate', '-')}Hz・{s.get('channels', '-')}ch（勧めは 48000Hz・2ch）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("script")
    ap.add_argument("--no-voice", action="store_true")
    ap.add_argument("--bgm")
    a = ap.parse_args()
    if a.bgm and not Path(a.bgm).is_file():              # 書き出してから気づくと、数分むだになる
        sys.exit(f"NG  BGM のファイルが無い: {a.bgm}")
    script = str(Path(a.script).resolve())
    run("1. 声と時刻", ["voice.py", script] + (["--no-voice"] if a.no_voice else []))
    print("\n=== 2. 長さ（書き出す前） ===")
    total = json.loads((HERE / "build" / "timing.json").read_text(encoding="utf-8"))["total"]
    if not length_ok(total):
        sys.exit("\n止めた: 長すぎる。台本を短くする")
    run("3. 文字の位置（書き出す前）", ["check_layout.py"])
    run("4. 書き出し", ["render.py"])
    run("5. 音を混ぜて、音量をそろえる", ["mix.py"] + (["--bgm", str(Path(a.bgm).resolve())] if a.bgm else ["--test-tone"] if a.no_voice else []))
    final = HERE / "build" / "final.mp4"
    run("6. 公開前の検査", ["video_qc.py", str(final)])
    print("\n=== 7. 音声の形 ===")
    audio_note(final)
    print("\n→ できた: build/final.mp4")


if __name__ == "__main__":
    main()
