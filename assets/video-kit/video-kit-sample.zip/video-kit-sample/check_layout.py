# -*- coding: utf-8 -*-
"""書き出す前に、0.2秒ごとに画面を止めて、文字の位置を測る。

  python check_layout.py        （scene.html と build/timing.json を使う。先に voice.py を流す）

  見るもの: 画面の外や、枠（data-box を付けた部品）からはみ出していないか／下から360px（Shorts の題名と説明）に入っていないか／
           右の操作ボタンの列に入っていないか／文字どうしが重なっていないか／字が小さすぎないか／
           最後の行が1〜2字だけになっていないか／声が鳴っている間に、その行の字幕が見えていて、台本どおりの文か
  文字は1字ずつ位置を取り、行ごとに判定する。文字でない部品は data-check を付けたものを測る。
  1つでも NG があれば終了コード 1（書き出しの前に止まる）。
  座標は正しくても変に見えるもの（単語の途中の改行など）は拾えないので、snap.py で撮って目でも見る。
"""
import json, re, sys
from pathlib import Path
from playwright.sync_api import sync_playwright

for _s in (sys.stdout, sys.stderr):
    if hasattr(_s, "reconfigure"):
        _s.reconfigure(encoding="utf-8", errors="replace")

HERE = Path(__file__).resolve().parent
W, H = 1080, 1920
SAFE_BOTTOM = 1560                     # これより下は Shorts の題名・説明が重なる
RIGHT_X, RIGHT_Y = 860, (760, 1780)    # 右の操作ボタン（高評価・コメントなど）が並ぶ場所
MIN_FONT = 28                          # スマホでは約3分の1の大きさで見える
STEP = 0.2

# 見えている文字を1字ずつ測り、行ごとの矩形と、最後の行の字数を返す。data-check の部品は箱で測る
MEASURE = """() => {
  const vis = el => { for (let e = el; e && e.nodeType === 1; e = e.parentElement) {
      const s = getComputedStyle(e);
      if (s.display === 'none' || s.visibility === 'hidden' || parseFloat(s.opacity) < 0.05) return false; }
    return true; };
  const els = [], items = [];
  for (const el of document.body.querySelectorAll('*')) {
    if (['SCRIPT', 'STYLE'].includes(el.tagName) || !vis(el)) continue;
    const own = [...el.childNodes].filter(n => n.nodeType === 3 && n.textContent.trim());
    if (own.length) {
      const fs = parseFloat(getComputedStyle(el).fontSize), lines = [];
      for (const n of own) {
        let i = 0;
        for (const ch of n.data) {                      // 絵文字（2つの符号単位）も1字として数える
          const len = ch.length;
          if (!/\\s/.test(ch)) {
            const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + len);
            const c = r.getClientRects()[0];
            if (c && c.width > 0) {
              const L = lines.find(x => Math.abs(x.t - c.top) < fs * 0.5);
              if (L) { L.l = Math.min(L.l, c.left); L.r = Math.max(L.r, c.right); L.b = Math.max(L.b, c.bottom); L.n++; }
              else lines.push({t: c.top, b: c.bottom, l: c.left, r: c.right, n: 1});
            }
          }
          i += len;
        }
      }
      if (!lines.length) continue;
      lines.sort((a, b) => a.t - b.t);
      // data-box を付けた枠（カードや字幕の帯）の中の文字は、その枠からはみ出していないかも見る
      const bx = el.closest('[data-box]'), br = bx && bx.getBoundingClientRect();
      const outbox = !!br && lines.some(x => x.l < br.left - 2 || x.r > br.right + 2 || x.t < br.top - 2 || x.b > br.bottom + 2);
      els.push(el);
      items.push({text: el.textContent.trim().slice(0, 20), fs, lines, lastn: lines[lines.length - 1].n, outbox});
    } else if (el.hasAttribute('data-check')) {
      const c = el.getBoundingClientRect();
      if (c.width > 0 && c.height > 0) {
        els.push(el);
        items.push({text: '[' + (el.id || el.tagName.toLowerCase()) + ']', fs: null, lines: [{t: c.top, b: c.bottom, l: c.left, r: c.right, n: 0}], lastn: null});
      }
    }
  }
  const box = it => ({l: Math.min(...it.lines.map(x => x.l)), t: it.lines[0].t, r: Math.max(...it.lines.map(x => x.r)), b: Math.max(...it.lines.map(x => x.b))});
  const over = [];
  for (let i = 0; i < items.length; i++) for (let j = i + 1; j < items.length; j++) {
    if (els[i].contains(els[j]) || els[j].contains(els[i])) continue;
    const hit = items[i].lines.some(a => items[j].lines.some(b =>
      Math.min(a.r, b.r) - Math.max(a.l, b.l) > 2 && Math.min(a.b, b.b) - Math.max(a.t, b.t) > 2));
    if (hit) over.push([items[i].text, items[j].text]);
  }
  items.forEach(it => Object.assign(it, box(it)));
  const cap = document.getElementById('cap');
  return {items, over, cap: cap ? {text: cap.textContent, shown: vis(cap)} : null};
}"""


def main():
    tj = HERE / "build" / "timing.json"
    if not tj.exists():
        print("NG  build/timing.json が無い。先に voice.py を流す")
        return 1
    tm = json.loads(tj.read_text(encoding="utf-8"))
    issues = {}                                  # (何が, どの文字) -> [最初の時刻, 回数]

    def add(kind, text, t):
        v = issues.setdefault((kind, text), [t, 0]); v[1] += 1

    same = lambda a, b: re.sub(r"\s", "", a or "") == re.sub(r"\s", "", b or "")
    n = int(tm["total"] / STEP) + 1
    errs = []
    with sync_playwright() as p:
        br = p.chromium.launch()
        pg = br.new_page(viewport={"width": W, "height": H}, device_scale_factor=1)
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.add_init_script("window.__CAPTURE = true; window.__DATA = " + json.dumps(tm, ensure_ascii=False) + ";")
        pg.goto((HERE / "scene.html").as_uri())
        pg.evaluate("document.fonts.ready.then(() => true)")
        if errs or not pg.evaluate("typeof window.__setTime === 'function'"):
            print("NG  scene.html が動いていない:", (errs or ["window.__setTime が無い"])[0][:160])
            br.close()
            return 1
        for k in range(n):
            t = round(k * STEP, 3)
            pg.evaluate(f"window.__setTime({t})")
            m = pg.evaluate(MEASURE)
            for it in m["items"]:
                s = it["text"]
                if it["l"] < 0 or it["t"] < 0 or it["r"] > W or it["b"] > H:
                    add("画面の外にはみ出した", s, t)
                if it.get("outbox"):
                    add("枠からはみ出した", s, t)
                if it["b"] > SAFE_BOTTOM:
                    add(f"下から{H - SAFE_BOTTOM}pxに入った（Shorts の題名に隠れる）", s, t)
                if any(ln["r"] > RIGHT_X and ln["b"] > RIGHT_Y[0] and ln["t"] < RIGHT_Y[1] for ln in it["lines"]):
                    add("右の操作ボタンの列に入った", s, t)
                if it["fs"] is not None and it["fs"] < MIN_FONT:
                    add(f"字が小さい（{it['fs']:.0f}px）", s, t)
                if it["lastn"] is not None and len(it["lines"]) >= 2 and it["lastn"] <= 2:
                    add("最後の行が1〜2字だけ", s, t)
            for a, b in m["over"]:
                add("文字が重なった", f"{a} × {b}", t)
            for ln in tm["lines"]:                   # 声が鳴っている間は、その行の字幕が見えているはず
                if ln["start"] <= t < ln["start"] + ln["dur"] and ln["caption"].strip():
                    c = m["cap"]
                    if not c or not c["shown"] or not same(c["text"], ln["caption"]):
                        add("字幕が声とずれた（見えていないか、別の行が出ている）", ln["caption"][:20], t)
        br.close()

    print(f"{n}時点を測った（{STEP}秒ごと・{tm['total']:.1f}秒）")
    for (kind, text), (t0, cnt) in sorted(issues.items(), key=lambda x: x[1][0]):
        print(f"NG  {t0:5.1f}秒〜  {kind}  「{text}」（{cnt}回）")
    if errs:
        print("NG  ページのエラー:", errs[0][:160])
    bad = len(issues) + len(errs)
    print("→ OK" if not bad else f"→ NG が {bad} 件。直してから書き出す")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
