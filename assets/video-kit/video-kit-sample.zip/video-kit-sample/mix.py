# -*- coding: utf-8 -*-
"""声と BGM を混ぜて映像に入れ、音量を YouTube の目標（-14 LUFS）にそろえる。

  python mix.py                       build/voice.wav があれば声を入れる
  python mix.py --bgm 好きな曲.mp3     BGM は、声が鳴っている間だけ下がる（ダッキング）
  python mix.py --test-tone           BGM の代わりに、試し用の和音を鳴らす（素材が無くても通しを試せる）
  出力: build/final.mp4（音声は 48kHz ステレオ）。目標の音量は video_qc.py の LUFS_TARGET を使う
"""
import argparse, json, subprocess, sys
from pathlib import Path

for _s in (sys.stdout, sys.stderr):
    if hasattr(_s, "reconfigure"):
        _s.reconfigure(encoding="utf-8", errors="replace")

HERE = Path(__file__).resolve().parent
BUILD = HERE / "build"
sys.path.insert(0, str(HERE))
from video_qc import LUFS_TARGET          # 検査と同じ目標にそろえる（別々に書くと、片方だけ変えて食い違う）

TP, LRA = -2.0, 11
TONE = "(0.2*sin(2*PI*220*t)+0.12*sin(2*PI*277.18*t)+0.1*sin(2*PI*329.63*t))*(0.75+0.25*sin(2*PI*0.5*t))"


def ff(args):
    return subprocess.run(["ffmpeg", "-y", "-hide_banner", *args], capture_output=True, text=True, encoding="utf-8", errors="replace")


def loud(path, extra=""):
    """loudnorm で測った値（音量・ピーク・…）を返す"""
    r = ff(["-i", str(path), "-af", f"loudnorm=I={LUFS_TARGET}:TP={TP}:LRA={LRA}{extra}:print_format=json", "-f", "null", "-"])
    return json.loads(r.stderr[r.stderr.rindex("{"): r.stderr.rindex("}") + 1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bgm")
    ap.add_argument("--test-tone", action="store_true")
    a = ap.parse_args()
    video, voice, mixed, out = BUILD / "video.mp4", BUILD / "voice.wav", BUILD / "mix.wav", BUILD / "final.mp4"
    out.unlink(missing_ok=True)            # 失敗したときに、前回の完成品が残って紛れないように
    if not video.exists():
        print("NG  build/video.mp4 が無い。先に render.py を流す")
        return 1
    if a.bgm and not Path(a.bgm).is_file():
        print(f"NG  BGM のファイルが無い: {a.bgm}")
        return 1
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(video)],
                       capture_output=True, text=True)
    d = float(r.stdout.strip())
    has_voice, has_bgm = voice.exists(), bool(a.bgm or a.test_tone)
    if not (has_voice or has_bgm):
        print("NG  声も BGM も無い（voice.py を声ありで流すか、--bgm か --test-tone を付ける）")
        return 1

    # 1. 声と BGM を混ぜる（まだ音量は合わせない）
    cmd, fl, n = [], [], 0
    if has_voice:
        cmd += ["-i", str(voice)]
        fl.append(f"[{n}:a]aresample=48000,aformat=channel_layouts=stereo,apad=whole_dur={d:.3f}[v]"); n += 1
    if has_bgm:
        cmd += ["-stream_loop", "-1", "-i", a.bgm] if a.bgm else ["-f", "lavfi", "-i", f"aevalsrc={TONE}:s=48000:d={d:.3f}"]
        fl.append(f"[{n}:a]aresample=48000,aformat=channel_layouts=stereo,atrim=0:{d:.3f},volume=0.24,"
                  f"afade=t=in:d=1.5,afade=t=out:st={max(0.0, d - 2.5):.3f}:d=2.5[b]"); n += 1
    if has_voice and has_bgm:
        # 声が鳴っている間だけ BGM を下げる。amix は normalize=0（既定のままだと本数で割られて小さくなる）
        fl.append("[v]asplit=2[v1][v2];[b][v1]sidechaincompress=threshold=0.04:ratio=8:attack=8:release=350[d];"
                  "[v2][d]amix=inputs=2:normalize=0:duration=first[m]")
    else:
        fl.append(("[v]" if has_voice else "[b]") + "anull[m]")
    r = ff([*cmd, "-filter_complex", ";".join(fl), "-map", "[m]", "-t", f"{d:.3f}", "-ar", "48000", "-ac", "2", str(mixed)])
    if r.returncode != 0:
        print("NG  声と BGM を混ぜられなかった:", r.stderr.strip().split("\n")[-1][:160])
        return 1

    # 2. 音量を合わせる。1回目で測り、2回目はその値を使って全体を同じだけ上げ下げする（2パス）
    m = loud(mixed)
    fix = (f"loudnorm=I={LUFS_TARGET}:TP={TP}:LRA={LRA}:measured_I={m['input_i']}:measured_TP={m['input_tp']}"
           f":measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true,aresample=48000")
    r = ff(["-i", str(video), "-i", str(mixed), "-map", "0:v", "-map", "1:a", "-af", fix, "-c:v", "copy",
            "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2", "-t", f"{d:.3f}", str(out)])
    if r.returncode != 0:
        print("NG  映像に音を入れられなかった:", r.stderr.strip().split("\n")[-1][:160])
        return 1
    j = loud(out)
    print(f"→ build/final.mp4  音量 {float(m['input_i']):.1f} → {float(j['input_i']):.1f} LUFS（目標 {LUFS_TARGET:g}）"
          f" / ピーク {float(j['input_tp']):.1f} dBTP")
    return 0


if __name__ == "__main__":
    sys.exit(main())
