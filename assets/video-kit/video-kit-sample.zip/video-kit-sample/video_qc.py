#!/usr/bin/env python3
"""書き出した動画を、公開前に自動で検査する（ffmpeg だけで動く）。

  python video_qc.py 動画.mp4        （Mac / Linux は python3）

  見るもの: 音の大きさ・音割れ・無音の穴・固まった画面・黒いコマ・冒頭の暗さ
  1つでも NG があれば終了コード 1 を返す（書き出しの後に続けて置ける）
  必要なもの: Python 3.8+ と ffmpeg / ffprobe（PATH が通っていること）
"""
import json, os, re, shutil, subprocess, sys

for _s in (sys.stdout, sys.stderr):
    if hasattr(_s, "reconfigure"):
        _s.reconfigure(encoding="utf-8", errors="replace")   # Git Bash などでも日本語を崩さない

# 基準（BGM のある YouTube 動画向けの目安。好みで変える）
LUFS_TARGET, LUFS_TOL = -14.0, 1.5   # 音の大きさ。YouTube の目標は -14。大きすぎると下げられ、小さすぎても目標までは上がらない
PEAK_MAX = -1.0                      # True Peak（dBTP）。0 に近いと再エンコードで割れやすい
SILENCE_DB, SILENCE_SEC = -50, 1.5   # この音量以下が、この秒数続いたら「無音の穴」
FREEZE_SEC = 3.0                     # 画面がこの秒数以上まったく変わらなければ「固まり」
BLACK_SEC = 0.1                      # 黒いコマ（画面の98%以上がほぼ黒）がこの秒数以上続いたら NG
FIRST_Y_MIN = 20                     # 0.5秒時点の平均の明るさ（黒=16、白=235）。ほぼ真っ黒で始まる動画を止める
END_GRACE = 2.0                      # 最後のこの秒数に始まる無音・黒はフェードアウトとみなして数えない


def ff(args):
    """ffmpeg を走らせて (終了コード, ログ) を返す"""
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", *args], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    return r.returncode, r.stderr


def num(s):
    return float("-inf") if s.endswith("inf") and s.startswith("-") else float(s)


def found(times, dur):
    """フェードアウトの分を除いて、見つかった時刻を返す（長さが分からない動画は全部数える）"""
    return [t for t in times if dur <= 0 or t < dur - END_GRACE]


def main(path):
    if not (shutil.which("ffmpeg") and shutil.which("ffprobe")):
        print("NG  ffmpeg / ffprobe が見つからない（入れたあと、ターミナルを開き直す）"); return 1
    pr = subprocess.run(["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", "-show_streams", path],
                        capture_output=True, text=True, encoding="utf-8", errors="replace")
    if pr.returncode != 0 or not pr.stdout.strip():
        print("NG  動画を読めない（パスか形式を確かめる）"); return 1
    info = json.loads(pr.stdout)
    dur = float(info["format"].get("duration") or 0)
    v = next((s for s in info["streams"] if s["codec_type"] == "video"), None)
    if v is None:
        print("NG  映像トラックがない（音声だけのファイル？）"); return 1
    a = next((s for s in info["streams"] if s["codec_type"] == "audio"), None)
    has_audio = a is not None
    vw, vh = v.get("width", 0), v.get("height", 0)
    rot = [d.get("rotation", 0) for d in v.get("side_data_list", []) if "rotation" in d] or [v.get("tags", {}).get("rotate", 0)]
    if abs(int(float(rot[0]))) % 180 == 90:
        vw, vh = vh, vw                                # スマホの縦動画（回転の情報つき）
    print(f'{os.path.basename(path)}  {dur:.1f}秒 / {vw}x{vh}')
    rows, logs = [], []

    if has_audio:
        rc, log = ff(["-i", path, "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"]); logs.append(log)
        i = re.findall(r"I:\s+(-?(?:[\d.]+|inf)) LUFS", log)
        p = re.findall(r"Peak:\s+(-?(?:[\d.]+|inf)) dBFS", log)
        if rc or not i or not p:
            rows.append(("音の大きさ", "解析できない", False))
        else:
            lufs, peak = num(i[-1]), num(p[-1])
            rows.append(("音の大きさ", f"{lufs:.1f} LUFS（目標 {LUFS_TARGET:g}±{LUFS_TOL:g}）", abs(lufs - LUFS_TARGET) <= LUFS_TOL))
            rows.append(("音割れ", f"ピーク {peak:.1f} dBTP（{PEAK_MAX:g} 以下）", peak <= PEAK_MAX))
        rc, log = ff(["-i", path, "-vn", "-af", f"silencedetect=n={SILENCE_DB}dB:d={SILENCE_SEC}", "-f", "null", "-"])
        holes = [num(t) for t in re.findall(r"silence_start: (-?[\d.]+)", log)]
        a_end = float(a.get("duration") or 0)
        if a_end and dur - a_end >= SILENCE_SEC:
            holes.append(a_end)                         # 音声が映像より先に終わっている
        holes = found(sorted(holes), dur)
        rows.append(("無音の穴", "解析できない" if rc else ("なし" if not holes else "あり: " + ", ".join(f"{t:.1f}秒〜" for t in holes[:5])), not rc and not holes))
    else:
        rows.append(("音", "音声トラックがない", False))

    rc, log = ff(["-i", path, "-an", "-vf", f"freezedetect=n=-60dB:d={FREEZE_SEC}", "-f", "null", "-"]); logs.append(log)
    frz = [num(t) for t in re.findall(r"freeze_start: (-?[\d.]+)", log)]
    rows.append(("固まった画面", "解析できない" if rc else ("なし" if not frz else "あり: " + ", ".join(f"{t:.1f}秒〜" for t in frz[:5])), not rc and not frz))

    rc, log = ff(["-i", path, "-an", "-vf", f"blackdetect=d={BLACK_SEC}:pix_th=0.10", "-f", "null", "-"])
    blk = found([num(t) for t in re.findall(r"black_start:(-?[\d.]+)", log)], dur)
    rows.append(("黒いコマ", "解析できない" if rc else ("なし" if not blk else "あり: " + ", ".join(f"{t:.1f}秒〜" for t in blk[:5])), not rc and not blk))

    # 10bit の動画でも 0〜255 で測れるよう、8bit に直してから明るさを取る
    rc, log = ff(["-ss", "0.5", "-i", path, "-an", "-frames:v", "1", "-vf", "format=yuv420p,signalstats,metadata=print", "-f", "null", "-"])
    y = re.findall(r"lavfi\.signalstats\.YAVG=([\d.]+)", log)
    first = float(y[0]) if y else 0.0
    rows.append(("冒頭の暗さ", f"明るさ {first:.0f}/255（{FIRST_Y_MIN} 以上）" if y else "測れない（0.5秒より短い？）", bool(y) and first >= FIRST_Y_MIN))
    # 途中で切れたファイルなど、読むときにエラーが出たら知らせる（ふだんは表示しない）
    if any(re.search(r"partial file|corrupt|Invalid data found|Error while decoding", g) for g in logs):
        rows.append(("壊れたデータ", "あり（書き出し直す）", False))

    w = max(len(r[0]) for r in rows)
    for name, val, ok in rows:
        print(f"{'OK' if ok else 'NG'}  {name}{'　' * (w - len(name))}  {val}")
    bad = sum(1 for r in rows if not r[2])
    print("→ 公開してよい" if bad == 0 else f"→ NG が {bad} 件。直してから公開")
    return 1 if bad else 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("使い方: python video_qc.py 動画.mp4")
    sys.exit(main(sys.argv[1]))
